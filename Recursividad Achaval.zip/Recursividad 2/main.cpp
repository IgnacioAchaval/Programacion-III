#include <iostream>

using namespace std;

int sumArray(int a[], int n) {
    if (n == 1) {
        return a[0];
    } else {
        return a[n - 1] + sumArray(a, n - 1);
    }
}

int main() {
    int *a;
    int sum = 0;
    int n = 0;
    cout << "ingrese la dimension del array " << endl;
    cin >> n;

    a = new int[n];

    for (int i = 0; i < n; i++) {
        cout << "ingrese el valor del elemento en la posicion " << i << ": ";
        cin >> a[i];
    }

    sum = sumArray(a, n);

    cout << "el valor de la suma del array es: " << sum << endl;

    return 0;
}
