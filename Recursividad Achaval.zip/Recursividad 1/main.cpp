#include <iostream>

using namespace std;

int potencia(int n, int e) {
    if (e == 0)
        return 1;
    int tmp=n * potencia(n, e - 1);
    return tmp;
}

int main() {
   /* if(potencia(2,6)==64)
        cout<<"test1 ok"<<endl;
    else
        cout<<"test1 fail"<<endl;*/ //esto es un testing
    cout << "2 a la 6 = " << potencia(2, 6) << endl;
    return 0;
}
