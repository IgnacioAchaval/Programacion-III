#include <iostream>

using namespace std;

int ackerman(int m, int n)
{
    if(m==0)
        return n+1;
    else
    if (m > 0 && n == 0)
        return ackerman(m - 1, 1);
    else
    if (m > 0 && n > 0)
        return ackerman(m - 1, ackerman(m, n - 1));
}

int main()
{
    int m, n, resultado=0;

    cout<<"ingrese m: ";
    cin>>m,
    cout<<"ingrese n: ";
    cin>>n;
    resultado=ackerman(m,n);
    cout<<resultado<<endl;
    return 0;
}