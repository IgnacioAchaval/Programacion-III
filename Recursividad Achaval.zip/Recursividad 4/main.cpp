#include <iostream>

using namespace std;

int euclides(int a, int b)
{
    while(b>0&&a>b)
    {
        if (b == 0) {
            return a;
        }
        else {
            return euclides(b, a % b);
        }
    }
}

int main()
{
    int a, b, resultado=0;
    cout<<"ingrese a: ";
    cin>>a;
    cout<<"ingrese b: ";
    cin>>b;
    resultado=euclides(a,b);
    cout<<resultado<<endl;
    return 0;
}